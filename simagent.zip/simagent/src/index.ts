import express, { Request, Response } from "express";
import cors from "cors";
import {
  BaseAgentRuntime,
  ClientConfig,
  Logger,
  LogLevel,
  Metadata,
  Persona,
} from "@sage/base";
import { SQLiteAdapter } from "@sage/databases-sqlite";
import { TelegramClient } from "@sage/clients-telegram";
import { RestClient } from "@sage/clients-rest";
import { Client } from "@sage/base";
import { createCosmosPlugin } from "@sage/connectors-cosmos";
import dotenv from "dotenv";
import { Connector, Meta } from "@sage/base";
import { TwitterClientInterface } from "@sage/clients-twitter";
import { generateRandomToken, WebCrawler } from "@sage/shared";
import { taskSchedulerPlugin } from "@sage/base";
import { MonitorConfig } from "@sage/base";
import { createExternalAPIsPlugin } from "@sage/explorer";
import { encrypt, decrypt } from './utils/crypto';
import { getAgentByDeploymentId } from './utils/arka';
import { constants } from './constants';

dotenv.config();

// Global state tracking
let isRunning = false;
let runtime: BaseAgentRuntime | null = null;
let logger = new Logger((process.env.LOG_LEVEL as LogLevel) || LogLevel.DEBUG);
let onChainAgentAddress: string = '';

// Create database adapter
const dbAdapter = new SQLiteAdapter("./bot.db");

// Client constructors mapping
const ClientConstructors: Record<
  string,
  new (runtime: BaseAgentRuntime, config: any) => Client
> = {
  telegram: TelegramClient,
  twitter: TwitterClientInterface,
};

// Initialize Express app
const app = express();
app.use(cors());
app.use(express.json());

app.post("/submit-character", async (req: Request, res: Response) => {
  if (isRunning) {
    return res.status(400).json({ message: "Agent is already running" });
  }

  try {
    const {
      modelDetails,
      agentPersona,
      clientConfigs,
      actions,
      agent_mnemonic,
      monitorConfig,
      runtimeSecrets,
      arkaConfigs
    } = req.body;
    const missingFields: string[] = [];

    if (!modelDetails) {
      missingFields.push("modelDetails");
    } else {
      if (!modelDetails.provider) missingFields.push("modelDetails.provider");
      if (!modelDetails.modelId) missingFields.push("modelDetails.modelId");
      if (!modelDetails.apiKey) missingFields.push("modelDetails.apiKey");
    }

    if (!agentPersona) {
      missingFields.push("agentPersona");
    } else {
      if (!agentPersona.name) missingFields.push("agentPersona.name");
      if (!agentPersona.description)
        missingFields.push("agentPersona.description");
      if (!agentPersona.bio) missingFields.push("agentPersona.bio");
    }

    if (monitorConfig) {
      if (!monitorConfig.url) {
        missingFields.push("monitorConfig.url");
      }
      if (!monitorConfig.token) {
        missingFields.push("monitorConfig.token");
      }
      if (!monitorConfig.org) {
        missingFields.push("monitorConfig.org");
      }
      if (!monitorConfig.bucket) {
        missingFields.push("monitorConfig.bucket");
      }
    }

    // Return detailed error if any fields are missing
    if (missingFields.length > 0) {
      return res.status(400).json({
        message: "Missing required fields",
        missingFields: missingFields,
      });
    }

    if (runtimeSecrets) {
      if (
        runtimeSecrets.accessSecret &&
        runtimeSecrets.accessSecret.length < 20
      ) {
        return res.status(400).json({
          message: "Invalid accessSecret: must be at least 20 characters long",
        });
      }

      if (
        runtimeSecrets.refreshSecret &&
        runtimeSecrets.refreshSecret.length < 20
      ) {
        return res.status(400).json({
          message: "Invalid refreshSecret: must be at least 20 characters long",
        });
      }
    }

    // After validation, fetch the agent address
    try {
      const deploymentId = constants.get('DEPLOYMENT_ID');
      if (!deploymentId) {
        throw new Error('DEPLOYMENT_ID not found in environment variables');
      }

      onChainAgentAddress = await getAgentByDeploymentId(
        arkaConfigs.restEndpoint,
        deploymentId
      );
      
      logger.info(`Found agent address: ${onChainAgentAddress}`);
    } catch (error) {
      logger.error('Failed to fetch agent address:', error);
      // return res.status(500).json({
      //   message: "Failed to fetch agent address",
      //   error: error instanceof Error ? error.message : "Unknown error",
      // });
    }

    const metadata: Metadata = {
      modelConfig: {
        MODEL_ID: modelDetails.modelId,
        provider: modelDetails.provider,
        secret: modelDetails.apiKey,
      },
      version: "0.0.1",
    };

    const personadata: Persona = {
      id: agentPersona.id,
      name: agentPersona.name,
      description: agentPersona.description,
      bio: agentPersona.bio,
      knowledge: agentPersona.knowledge,
    };

    // After validation, encrypt the entire configuration
    const configToEncrypt = {
      modelDetails,
      agentPersona,
      clientConfigs,
      actions,
      agent_mnemonic,
      monitorConfig,
      runtimeSecrets,
      arkaConfigs
    };

    // Encrypt the configuration
    const encryptedConfig = encrypt(configToEncrypt);

    // Create runtime with encrypted config
    runtime = new BaseAgentRuntime(
      crypto.randomUUID() as string,
      personadata,
      metadata,
      dbAdapter,
      [],
      monitorConfig,
      arkaConfigs,
      encryptedConfig,
      onChainAgentAddress,
      logger,
      new Date().getTime(),
      runtimeSecrets,
    );
    if (!runtime.address) {
      await runtime.generateAddress(agent_mnemonic);
    }

    // Now create the Cosmos plugin, passing the runtime
    const cosmosPlugin = createCosmosPlugin(runtime);
    const tasksPlugin = taskSchedulerPlugin();
    const externalClientPlugin = createExternalAPIsPlugin();

    // Populate AllConnectors with the runtime-aware plugin
    const AllConnectors: Connector[] = [
      cosmosPlugin,
      tasksPlugin,
      externalClientPlugin,
    ];

    // Finally, update the runtime with the connectors
    runtime.setConnectors(AllConnectors);

    // Initialize runtime and clients
    await runtime.initialize();

    //Setting the InfluxDb Instance for monitoring
    if (runtime.monitor) {
      runtime.database.setMonitorInstance(runtime.monitor);
    }
    await initializeClients(runtime, clientConfigs);

    // NOTE: tensorflow embedding will take around 1 minute to load so adding delayed execution for initializing
    // knowledge.
    ((runtime: BaseAgentRuntime) => {
      setTimeout(async () => {
        const crawler = new WebCrawler(runtime.logger);
        const knowledges: string[] = [];

        if (typeof personadata.knowledge === "string") {
          if (isValidUrl(personadata.knowledge)) {
            const result = await crawler.crawl(personadata.knowledge);
            knowledges.push(result);
          } else {
            knowledges.push(personadata.knowledge);
          }
          knowledges.push(personadata.knowledge);
        } else if (Array.isArray(personadata.knowledge)) {
          for (let index = 0; index < personadata.knowledge.length; index++) {
            const url = personadata.knowledge[index];
            if (isValidUrl(url)) {
              const result = await crawler.crawl(url);
              knowledges.push(result);
            } else {
              knowledges.push(url);
            }
          }
        }
        await runtime.addKnowledge(knowledges);
      }, 60_000);
    })(runtime);
    isRunning = true;

    runtime.registerGRPCServices();
    await runtime.startGRPCServer(5678);

    res.status(200).json({
      message: "Character received successfully!",
      running: true,
    });
  } catch (error: any) {
    isRunning = false;
    console.error("Initialization failed:", error);
    res.status(500).json({
      message: "Failed to initialize agent",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
});
app.get("/update", async (req: Request, res: Response) => {
  if (!runtime) {
    return res.status(400).json({
      message: "Runtime is not initialized",
      running: false,
    });
  }

  try {
    const { clientConfigs } = req.body;
    await updateClients(runtime, clientConfigs);
    res.status(200).json({
      message: "Clients update process completed",
      running: true,
    });
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error occurred";
    console.error("Error updating clients:", errorMessage);
    res.status(500).json({
      message: "Error updating clients",
      error: errorMessage,
    });
  }
});

async function initializeClients(
  runtime: BaseAgentRuntime,
  configs: ClientConfig[]
) {
  let clients: string[] = [];

  // run rest client by default
  const restInstance = new RestClient(runtime, {});
  await restInstance.start();
  runtime.registerExpressRoutes(restInstance.app, []);
  clients.push("direct");

  for (const config of configs) {
    const ClientConstructor = ClientConstructors[config.name];

    if (ClientConstructor) {
      try {
        const instance = new ClientConstructor(runtime, config);
        await instance.start();
        clients.push(config.name);
        runtime.clients.push(instance);
      } catch (error: any) {
        logger.error(`Failed to start client ${config.name}:`, error);
        throw new Error(`Failed to start client ${config.name}: ${error}`);
      }
    } else {
      runtime.logger.warn("Invalid input. Unsupported client configuration.");
    }
  }
  return clients;
}
async function updateClients(
  runtime: BaseAgentRuntime,
  clientConfigs: Record<string, any>[]
) {
  clientConfigs.forEach(async (clientConfig) => {
    const clientIndex = runtime.clients.findIndex(
      (c) => c.name === clientConfig.name
    );

    if (clientIndex !== -1) {
      const client = runtime.clients[clientIndex];

      try {
        // Stop the client
        if (client.running === "ACTIVE") {
          await client.stop();
        }
        runtime.clients.splice(clientIndex, 1);
        console.log(`Client ${clientConfig.name} stopped and removed`);

        // Add delay for cleanup (2 seconds)
        await new Promise((resolve) => setTimeout(resolve, 2000));

        // Start the new client
        const ClientConstructor = ClientConstructors[clientConfig.name];
        if (ClientConstructor) {
          const newInstance = new ClientConstructor(runtime, clientConfig);
          await newInstance.start();
          runtime.clients.push(newInstance);
          console.log(`Client ${clientConfig.name} restarted successfully`);
        } else {
          console.warn(`Client constructor not found for ${clientConfig.name}`);
        }
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : String(error);
        console.error(
          `Error processing client ${clientConfig.name}:`,
          errorMessage
        );
      }
    } else {
      console.log(`Client ${clientConfig.name} not found`);
      try {
        // Start the new client
        const ClientConstructor = ClientConstructors[clientConfig.name];
        if (ClientConstructor) {
          const newInstance = new ClientConstructor(runtime, clientConfig);
          await newInstance.start();
          runtime.clients.push(newInstance);
          console.log(`Client ${clientConfig.name} restarted successfully`);
        } else {
          console.warn(`Client constructor not found for ${clientConfig.name}`);
        }
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : String(error);
        console.error(
          `Error processing client ${clientConfig.name}:`,
          errorMessage
        );
      }
    }
  });
}

// Status route
app.get("/status", (_: Request, res: Response) => {
  res.status(200).json({
    running: isRunning,
  });
});

// Start the server
const PORT = 3000;
const server = app.listen(PORT, () => {
  logger.info(`Server running on http://localhost:${PORT}`);
});
app.post("/getsnapshot", async (req: Request, res: Response) => {
  const { snapshot, key } = req.body // Ensure it's intended as a number

  try {
    const snapshotreq = {
      agentAddress: "arka190s7z86rrgqmaxhvmerxm2cj9qnz0jq4ng526rcu435k39fqjctsl3tuey",
      key: key, // Converts string "1" to Uint8Array
      snapshot: snapshot, // Ensure it's intended as a number
      sender: "arka1eax5hywz2avsrah4v8uc6n2d9yjc2g7vf58yay",
    };

    // Ensure `runtime.downloadSnapshot` is an async function
    const resp = await runtime?.downloadSnapshot(snapshotreq);

    // Log and send response
    console.log("Snapshot Response:", resp);
    res.json({ snapshot: resp?.snapshot.toString() });
  } catch (error) {
    console.error("Error fetching snapshot:", error);
    res.status(500).json({ error: "Failed to fetch snapshot" });
  }
});


app.post("/submitsnapshot", async (req: Request, res: Response) => {
  try {
    const { snapshot } = req.body;

    if (!snapshot) {
      return res.status(400).json({ error: "Snapshot is required" });
    }
    await runtime?.submitSnapshot(snapshot, "arka190s7z86rrgqmaxhvmerxm2cj9qnz0jq4ng526rcu435k39fqjctsl3tuey"); // TODO
    res.status(200).json({ message: "Snapshot submitted successfully" });
  } catch (error) {
    console.error("Error submitting snapshot:", error);
    res.status(500).json({ error: "Failed to submit snapshot" });
  }
});


// Add graceful shutdown handling
process.on('SIGTERM', () => {
  logger.info('Received SIGTERM signal. Shutting down...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

// Add graceful shutdown handling
process.on('SIGINT', () => {
  logger.info('Received SIGINT signal. Shutting down...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});
function isValidUrl(str: string): boolean {
  try {
    const url = new URL(str);
    return /^https?:/.test(url.protocol);
  } catch {
    return false;
  }
}
