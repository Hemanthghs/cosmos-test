import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize dotenv
dotenv.config();

class Constants {
    private static instance: Constants;
    private envVars: Map<string, string>;
    private envFilePath: string;

    private constructor() {
        this.envVars = new Map<string, string>();
        // Set the .env file path relative to src directory
        this.envFilePath = path.resolve(__dirname, '../.env');
        
        // Initialize with current process.env values
        Object.entries(process.env).forEach(([key, value]) => {
            if (value) {
                this.envVars.set(key, value);
            }
        });
    }

    public static getInstance(): Constants {
        if (!Constants.instance) {
            Constants.instance = new Constants();
        }
        return Constants.instance;
    }

    /**
     * Get an environment variable
     * @param name The name of the environment variable
     * @param defaultValue Optional default value if the variable is not set
     * @returns The value of the environment variable or the default value
     */
    public get(name: string, defaultValue?: string): string | undefined {
        const value = this.envVars.get(name) || process.env[name];
        return value || defaultValue;
    }

    /**
     * Set an environment variable and update the .env file
     * @param name The name of the environment variable
     * @param value The value to set
     * @returns true if set successfully
     */
    public set(name: string, value: string): boolean {
        try {
            // Update runtime environment
            this.envVars.set(name, value);
            process.env[name] = value;

            // Read current .env file content
            let envContent = '';
            try {
                envContent = fs.readFileSync(this.envFilePath, 'utf-8');
            } catch (error) {
                // File doesn't exist, start with empty content
                envContent = '';
            }

            // Split into lines and parse existing variables
            const lines = envContent.split('\n');
            let found = false;

            // Update existing variable or prepare to add new one
            const updatedLines = lines.map(line => {
                if (line.startsWith(`${name}=`)) {
                    found = true;
                    return `${name}=${value}`;
                }
                return line;
            });

            // Add new variable if it wasn't found
            if (!found) {
                updatedLines.push(`${name}=${value}`);
            }

            // Write back to .env file
            fs.writeFileSync(this.envFilePath, updatedLines.join('\n'));

            return true;
        } catch (error) {
            console.error(`Error setting environment variable ${name}:`, error);
            return false;
        }
    }

    /**
     * Get all environment variables
     * @returns Object containing all environment variables
     */
    public getAll(): Record<string, string> {
        return Object.fromEntries(this.envVars);
    }

    /**
     * Check if an environment variable exists
     * @param name The name of the environment variable
     * @returns boolean indicating if the variable exists
     */
    public has(name: string): boolean {
        return this.envVars.has(name) || name in process.env;
    }
}

// Export a singleton instance
export const constants = Constants.getInstance();

// Example usage:
// import { constants } from './constants';
// const value = constants.get('MY_VAR', 'default');
// constants.set('NEW_VAR', 'value'); 