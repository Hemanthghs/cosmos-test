import crypto from 'crypto';
import { constants } from '../constants';

/**
 * Encrypts data using AES-256-CBC
 * @param data Object to encrypt
 * @returns encrypted string
 */
export function encrypt(data: any): string {
    const ENCRYPTION_KEY = constants.get('ENCRYPTION_KEY');
    const IV_KEY = constants.get('IV_KEY');

    if (!ENCRYPTION_KEY || !IV_KEY) {
        // Generate new keys if they don't exist
        const newKey = crypto.randomBytes(32).toString('hex');
        const newIV = crypto.randomBytes(16).toString('hex');
        constants.set('ENCRYPTION_KEY', newKey);
        constants.set('IV_KEY', newIV);
        return encrypt(data); // Retry with new keys
    }

    try {
        const iv = Buffer.from(IV_KEY, 'hex');
        const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
        const jsonStr = JSON.stringify(data);
        let encrypted = cipher.update(jsonStr, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return encrypted;
    } catch (error) {
        console.error('Encryption error:', error);
        throw new Error('Failed to encrypt data');
    }
}

/**
 * Decrypts data using AES-256-CBC
 * @param encryptedData Encrypted string to decrypt
 * @returns decrypted object
 */
export function decrypt(encryptedData: string): any {
    const ENCRYPTION_KEY = constants.get('ENCRYPTION_KEY');
    const IV_KEY = constants.get('IV_KEY');

    if (!ENCRYPTION_KEY || !IV_KEY) {
        throw new Error('Encryption keys not found');
    }

    try {
        const iv = Buffer.from(IV_KEY, 'hex');
        const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
        let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return JSON.parse(decrypted);
    } catch (error) {
        console.error('Decryption error:', error);
        throw new Error('Failed to decrypt data');
    }
} 