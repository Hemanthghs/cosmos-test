
interface AgentResponse {
  agent: {
    address: string;
    name: string;
    description: string;
    twitter: string;
    github: string;
    forum: string;
    website: string;
    logo: string;
    wallet_address: string;
    deployment_id: string;
    inference_price: {
      denom: string;
      amount: string;
    };
    created_at: string;
    pool_id: string;
    require_proof: boolean;
    inference_result_submitters: string[];
    endpoints: string[];
    creator: string;
    denom: string;
  };
}

/**
 * Fetches agent information by deployment ID
 * @param restEndpoint - The REST endpoint URL
 * @param deploymentId - The deployment ID to query
 * @returns The agent address if found
 * @throws Error if the request fails or agent is not found
 */
export async function getAgentByDeploymentId(
  restEndpoint: string,
  deploymentId: string
): Promise<string> {
  try {
    const url = `${restEndpoint}/arka/agent/v1beta1/agent-by-deployment/${deploymentId}`;
    
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json() as AgentResponse;
    
    if (!data?.agent?.address) {
      throw new Error('Agent address not found in response');
    }

    return data.agent.address;
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to fetch agent: ${error.message}`);
    }
    throw new Error('An unknown error occurred while fetching agent');
  }
}
